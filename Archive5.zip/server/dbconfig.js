// MYSQL
const mysql = require("mysql");
const connection = mysql.createConnection({
  host: process.env.RDS_HOSTNAME,
  user: process.env.RDS_USERNAME,
  password: process.env.RDS_PASSWORD,
  port: process.env.RDS_PORT,
  database: process.env.RDS_DB_NAME,
  multipleStatements: true
});

// console.log('****PROCESS.ENV**** ', process.env);
console.log('==============NEWEST VERSION===============');
console.log('****PROCESS.ENV**** ', process.env.RDS_HOSTNAME);
console.log('****PROCESS.ENV**** ', process.env.RDS_USERNAME);
console.log('****PROCESS.ENV**** ', process.env.RDS_PASSWORD);
console.log('****PROCESS.ENV**** ', process.env.RDS_PORT);

connection.connect(function(err) {
  if (err) {
    console.error("Database connection failed: " + err.stack);
    return;
  }
  console.log("Connected to database.");
});

module.exports = connection;