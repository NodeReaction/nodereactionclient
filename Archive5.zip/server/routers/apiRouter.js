"use strict";

// EXPRESS
const express = require("express");
const request = require("request");
const router = express.Router();

// CONTROLLERS
const agentController = require("./../controllers/agentController");
const routeController = require("./../controllers/routeController");
const traceController = require("./../controllers/traceController");
const apiController = require("./../controllers/apiController");
const dashboardController = require("./../controllers/dashboardController");
const analyticsController = require("./../controllers/analyticsController");

// ROUTES
// AGENT - POSTS DATA TO SERVER
router.post(
  "/agent/data/save",
  agentController.validate,
  agentController.create,
  (req, res) => {
    res.end();
  }
);

// ROUTES
router.get("/getData", apiController.getTransactions, (req, res) => {
  res.json(res.locals.transactions);
});

router.get("/deleteData", apiController.deleteTransactions, (req, res) => {
  res.json({ msg: "allset" });
});

router.get("/traces/:offset", traceController);

router.get("/dashboard/top/:offset", dashboardController.topFive);

router.get("/dashboard/stats/:offset", dashboardController.quickStats);

router.get("/routes/:offset", routeController.getRoutes);

router.get("/analytics/graph/:route/:method/:offset/:time", analyticsController.graphData);

// DEFAULT ROUTES
router.all("*", (req, res, next) => {
  const err = new Error(
    `apiRouter.js - default catch all route - not found - ${req.url}`
  );
  err.status = 404;
  next(err);
});

module.exports = router;
